<?php
$page = (@$_GET['page'] == '') ? 'home' : $_GET['page'];
if ($page == '404') header('Location: /');
include('include/header.php');
include('include/nav.php');

include("page/$page.php");

include('include/footer.php');