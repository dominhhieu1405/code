<?php
error_reporting(0);
$server = @$_GET['server'];

$hostname = "play.sinhton.xyz";

if ($server == 'java') {
	$check = json_decode(file_get_contents("https://api.mcsrvstat.us/2/$hostname"),true);
} else if ($server == 'bedrock') {
	$check = json_decode(file_get_contents("https://api.mcsrvstat.us/bedrock/2/$hostname"),true);
} else {
	die('Error!');
	exit();
}

$status = $check['online'];

if ($status) {
	$version = $check['version'];
	$online = $check['players']['online'];
	$max = $check['players']['max'];
	$players = ($online > 0) ? $check['players']['list'] : [];
} else {
	$version = "Unknown";
	$online = 0;
	$max = 0;
	$players = [];
}

$result = [
	'hostname' => $hostname,
	'status' => $status,
	'version' => $version,
	'online' => $online,
	'max' => $max,
	'players' => $players
];

die(json_encode($result));