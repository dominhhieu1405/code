function load_server(){
	$.get('/ping.php?server=java', function (e) {
		if (e.status) {
			$("#java-sv-status").attr("class", "mcserver-solo-online");
		} else {
			$("#java-sv-status").attr("class", "mcserver-solo-offline");
		}
		$("#java-sv-online").text(e.online);
		$("#java-sv-max").text(e.max);
		$("#java-sv-version").text(e.version);
		$("#java-sv-ip").text(e.hostname);
	}, 'json');
	$.get('/ping.php?server=bedrock', function (e) {
		if (e.status) {
			$("#bedrock-sv-status").attr("class", "mcserver-solo-online");
		} else {
			$("#bedrock-sv-status").attr("class", "mcserver-solo-offline");
		}
		$("#bedrock-sv-online").text(e.online);
		$("#bedrock-sv-max").text(e.max);
		$("#bedrock-sv-version").text(e.version);
		$("#bedrock-sv-ip").text(e.hostname);
	}, 'json');
}
$(function() {
	load_server();
	setInterval(function(){
		load_server();
	}, 13000);
});