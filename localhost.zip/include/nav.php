<body class="home page-template-default page page-id-2 custom-background unselectable">
    <div id="container">
        <header class="header" role="banner">
            <div id="inner-header" class="wrap clearfix">
                <p id="logo">
                    <a href="/" data-wpel-link="internal">
                        <img src="/assets/img/logo.png" alt="logo" title="SinhTon.xyz" />
                    </a>
                </p>

                <div class="menu-wrapper">
                    <a href="#menu" class="menu-link"> Menu<span class="ico-caret-down" aria-hidden="true"></span> </a>

                    <nav class="skin-bg" id="main-menu" role="navigation">
                        <ul id="menu-page" class="nav top-nav clearfix">
                            <li id="menu-item-3819" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3819"><a href="/" data-wpel-link="internal">Trang chủ</a></li>
                            <li id="menu-item-2505" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-2505"><a href="/rule" data-wpel-link="internal">Luật chơi</a></li>
                            <li id="menu-item-2505" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-2505"><a href="/download" data-wpel-link="internal">Tải game</a></li>
                            <!--<li id="menu-item-3728" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-3728"><a href="/donate" data-wpel-link="internal">Donate</a></li>-->
                        </ul>
                    </nav>

                    <div class="creepy-main-border creepy-3d-border">
                        <span class="border-left"></span>
                        <span class="border-middle"><span></span></span>
                        <span class="border-right"></span>
                    </div>
                </div>
            </div>
        </header>
        <div id="content">
            <div id="inner-content" class="wrap clearfix">
                <div id="main" class="ninecol first clearfix" role="main" style="padding-top:13px">