                </div>
                <div class="sidebar threecol last clearfix" role="complementary" style="padding-top: 13px">
                    <div class="widget-first widget widget_mcsolo_server_status">
                        <div class="widget-first inner-widget clearfix">
                            <h4 class="widgettitle">
                                <div class="inner-title">Máy chủ Java</div>

                                <div class="creepy-main-border creepy-3d-border widget-border">
                                    <span class="border-left"></span><span class="border-middle"><span></span></span><span class="border-right"></span>
                                </div>
                            </h4>

                            <p id="java-sv-status" class="mcserver-solo-online">
                                <strong><span id="java-sv-online">0</span>/<span id="java-sv-max">0</span></strong>
                            </p>

                            <p class="mcplayers-solo"><strong>666</strong><span>thành viên</span></p>

                            <p class="mcip-solo">IP: <strong id="java-sv-ip">play.minecraft.com</strong></p>

                            <p class="mcversion-solo">Phiên bản: <strong id="java-sv-version">0</strong></p>

                            <p class="mcsolo-shortdescription">
                                <b>Thông tin:</b> Máy chủ sinh tồn cho minecraft Java Edition 
                            </p>
                        </div>

                        <div class="creepy-content-border creepy-3d-border widget-border">
                            <span class="border-left"></span><span class="border-middle"><span></span></span><span class="border-right"></span>
                        </div>
                    </div>
                    
                    <div class="widget-first widget widget_mcsolo_server_status">
                        <div class="widget-first inner-widget clearfix">
                            <h4 class="widgettitle">
                                <div class="inner-title">Máy chủ Bedrock</div>

                                <div class="creepy-main-border creepy-3d-border widget-border">
                                    <span class="border-left"></span><span class="border-middle"><span></span></span><span class="border-right"></span>
                                </div>
                            </h4>

                            <p id="bedrock-sv-status" class="mcserver-solo-online">
                                <strong><span id="bedrock-sv-online">0</span>/<span id="bedrock-sv-max">0</span></strong>
                            </p>

                            <p class="mcplayers-solo"><strong>666</strong><span>thành viên</span></p>

                            <p class="mcip-solo">IP: <strong id="bedrock-sv-ip">play.minecraft.com</strong></p>

                            <p class="mcversion-solo">Phiên bản: <strong id="bedrock-sv-version">0</strong></p>

                            <p class="mcsolo-shortdescription">
                                <b>Thông tin:</b> Máy chủ sinh tồn cho minecraft Bedrock Edition 
                            </p>
                        </div>

                        <div class="creepy-content-border creepy-3d-border widget-border">
                            <span class="border-left"></span><span class="border-middle"><span></span></span><span class="border-right"></span>
                        </div>
                    </div>
                    
                </div>
            </div>

            <div class="creepy-main-border creepy-3d-border wrap">
                <span class="border-left"></span><span class="border-middle"><span></span></span><span class="border-right"></span>
            </div>
        </div>

        <footer class="footer" role="contentinfo">
            <div id="inner-footer" class="wrap clearfix" align="center">
                <div id="footer-widgets" class="twelvecol"></div>

                <div class="footer-bottom clearfix">
                    <p class="source-org copyright">&copy; 2021 Minecraft Survival Server SinhTon.XYZ <span id="copyright-message"></span></p>
                </div>
            </div>

            <div class="creepy-footer-border creepy-3d-border wrap">
                <span class="border-left"></span><span class="border-middle"><span></span></span><span class="border-right"></span>
            </div>
        </footer>
    </div>

    <script type="text/javascript" src="/assets/js/scripts.js"></script>
    <script type="text/javascript" src="/assets/js/custom.js?t=<?=time();?>"></script>
</body>
