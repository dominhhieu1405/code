<!doctype html>
<html lang="vi">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/> 
	<meta name="robots" content="index, follow" />
	<meta name="description" content="Server Minecraft Việt Nam miễn phí đông người chơi. Máy chủ Minecraft thể loại sinh tồn đơn giản mà thú vị! Hãy thử tham gia trải nghiệm" />
	
	<link rel="apple-touch-icon" type="image/png" href="/assets/img/favicon.png"/>
	<link rel="icon" type="image/png" href="/assets/img/favicon.png"/>
	<link rel="shortcut icon" type="image/png" href="/assets/img/favicon.png"/>
	
	<title>Server Minecraft Sinh tồn Việt Nam | SinhTon.xyz</title>
	
	<link rel='stylesheet' href="/assets/libs/block-library/style.min.css" type='text/css'/>
	<link rel='stylesheet' href='/assets/css/style.css' type='text/css'/>
	<link rel='stylesheet' href='//fonts.googleapis.com/css?family=Roboto%3A400%2C300italic%2C300%2C400italic%2C700%2C700italic&#038;subset=latin%2Clatin-ext' type='text/css'/> 
	<link rel='stylesheet' href='/assets/css/custom.css?t=<?=time();?>' type='text/css'/>
	
	<script type='text/javascript' src='/assets/js/jquery.min.js'></script>
	<!--<script type='text/javascript' src='/assets/js/modernizr.custom.min.js'></script>-->
	
</head>