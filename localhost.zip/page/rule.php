
                    <div class="inner-bg">
                        <article id="post-2" class="clearfix post-2 page type-page status-publish hentry" role="article">
                        	 <img src="/assets/img/rule.jpg" class="magicraft-single-thumb" style="width:100%"/>


                            <header class="article-header">
                                <h1 class="page-title" itemprop="headline">Luật chơi</h1>
                            </header>

                            <section class="entry-content clearfix" itemprop="articleBody">
                                <p>SinhTon.XYZ có những quy định chung như sau để chắc chắn mọi người không làm ảnh hưởng đến trải nghiệm của người khác.</p>
                                <p>Thành viên vi phạm quy tắc sẽ bị tước quyền truy cập tài khoản ngay lập tức.</p>
                                <br/>
                                <p><strong>Không lạm dụng: </strong>Không lạm dụng các chức năng được mở để gây lag server ảnh hưởng đến người khác như xây lag machine, spam minecart, armor stand, ...</p>
                                <p><strong>Không gian lận: </strong>Không sử dụng các bản client/launcher đã chỉnh sửa để hack. Không sử dụng bot, các tool hỗ trợ, gói tài nguyên x-ray hoặc radar/mini map khi tham gia trò chơi.</p>
                                <p><strong>Không bug: </strong> Không lợi dụng bug hoặc exploits để tránh bị khoá tài khoản. Vui lòng thông báo cho chúng tôi nếu bạn phát hiện bug qua Email hoặc Facebook của chúng tôi. Bạn sẽ nhận được phần thưởng xứng đáng.</p>

                            </section>
                            <footer class="article-footer"></footer>
                        </article>
                    </div>

                    <div class="creepy-content-border creepy-3d-border">
                        <span class="border-left"></span><span class="border-middle"><span></span></span><span class="border-right"></span>
                    </div>