
                    <div class="inner-bg">
                        <article id="post-2" class="clearfix post-2 page type-page status-publish hentry" role="article">

                            <header class="article-header">
                                <h1 class="page-title" itemprop="headline">Giới thiệu</h1>
                            </header>

                            <section class="entry-content clearfix" itemprop="articleBody">

                                <h2 style="text-align: center;">
                                	SinhTồn.XYZ
                                </h2>

                                <p>
                                    <b>Minecraft </b>là một trò chơi điện tử độc lập trong một thế giới mở với phong cách sandbox, được phát hành vào năm 2009 bởi lập trình viên người Thụy Điển Markus "Notch" Persson và sau đó được phát triển và phát hành bởi Mojang Studio.
                                </p>
                                <p>
                                	Và chúng tôi sử dụng mã nguồn mở này để thành lập ra server minecraft sinh tồn cho cả Minecraft Java Edition và Bedrock Edition vào ngày <strong>26/10/2021</strong>. Để tham gia máy chủ Sinh Tồn các bạn cần <a href="/download" target="_blank" rel="noopener noreferrer" data-wpel-link="internal">tải minecraft</a> và truy cập vào server bằng ip:<strong> Play.SinhTon.XYZ</strong>
                                </p>
                                <h3 style="text-align: left;" data-redactor="1">Chế độ chơi: <b>Sinh tồn</b></h3>
                                <p>Chế độ chơi bình thường và mặc định trong Minecraft, tất cả đều giống như chế độ chơi đơn khi bạn chơi Minecraft Offline hay chơi mạng Lan! Nhưng ở đây bạn có thể chơi chung với bạn bè trên mọi miền Việt Nam.</p>

                                <h3><strong>Giới thiệu :</strong></h3>
                                <p>sinhton.xyz không hề có bất cứ một quản trị viên nào và cùng với đó sẽ không hề có một luật lệ nào được đặt ra, điều này có nghĩa là bạn sẽ không bị BanIP cho dù có làm điều gì đi chăng nữa.</p>
                                <p>Kể cá dù công trình có bị phá nhưng những gì các bạn đã xây nên vẫn sẽ còn chút gì đó để khắc lại trong trang sử của sinhton.xyz. Mọi block sẽ được lưu trong thế giới đến khi nào server không còn đủ kinh phí duy trì nữa.</p>
                                <p>Dù rằng không có luật lệ nhưng không có nghĩa server không có anticheat, SinhTon.xyz cố gắng giữ những thứ cốt lõi nhất của chế độ sinh tồn và độ khó của game ngoài ra người chơi hack được gì thì hack thoải mái. </p>
                            </section>
                            <footer class="article-footer"></footer>
                        </article>
                    </div>

                    <div class="creepy-content-border creepy-3d-border">
                        <span class="border-left"></span><span class="border-middle"><span></span></span><span class="border-right"></span>
                    </div>
