
                    <div class="inner-bg">
                        <article id="post-2" class="clearfix post-2 page type-page status-publish hentry" role="article">
                            <img src="/assets/img/minecraft.jpg" class="magicraft-single-thumb" style="width:100%"/>


                            <header class="article-header">
                                <h1 class="page-title" itemprop="headline">Tải minecraft</h1>
                            </header>

                            <section class="entry-content clearfix" itemprop="articleBody">
                                <h2>Tải Minecraft Java Edition:</h2>
                                <h3>1. Giới thiệu</h3>
                                <p><em><strong>Laucher Minecraft</strong></em> là giao diện người dùng đăng nhập và tải xuống cho máy khách độc lập. Nó chịu trách nhiệm tải xuống các gói Java chính, bao gồm <b>minecraft.jar</b> , chứa mã và tài nguyên của trò chơi, chẳng hạn như kết cấu và LWJGL. Nó cũng hoạt động hơi giống như một hạn chế sao chép cơ bản và dễ dàng bỏ qua bằng cách buộc người dùng đăng nhập vào tài khoản phải trả tiền khi chạy lần đầu tiên. Có thể sử dụng để chơi hầu hết các phiên bản <b>Minecraft</b></p>
                                <h3>2. Tải <b>TLauncher</b></h3>
                                <img src="/assets/img/tlauncher.png" class="aligncenter" title="Tlauncher" style="width:100%;">
                                <p><b>Tlauncher</b> là một trình khởi chạy miễn phí cho Minecraft cho phép người dùng sửa đổi một số đặc điểm chính thức của trò chơi. TLauncher là chọn lựa thay thế tốt nhất cho Minecraft Launcher, giúp game thủ trải nghiệm thế giới mở theo nhiều cách khác nhau.</p>
                                <p>Nhấn vào nút <b>Download</b>  bên dưới để truy cập trang tải xuổng</p>
                                <a href="https://tlauncher.org/">
                                    <div class="mc-menu">
                                        <div class="mc-button ">
                                            <div class="title">Download</div>
                                        </div>
                                    </div>
                                </a>
                                <h3>3. Tải JAVA</h3>
                                <p>Để chạy được <b>Launcher Minecraft</b> bạn cần cài đặt thêm Java. Java là một ngôn ngữ lập trình hỗ trợ để để chơi Minecraft. Nếu bạn không cài java thì không chơi được <strong>Minecraft</strong>.</p>
                                <p>Nhấn vào nút <b>Download</b>  bên dưới để truy cập trang tải xuổng</p>
                                <a href="https://www.java.com/en/download/">
                                    <div class="mc-menu">
                                        <div class="mc-button ">
                                            <div class="title">Download</div>
                                        </div>
                                    </div>
                                </a>
                                <h3>4. Cấu Hình Yêu Cầu</h3>
                                <ul>
                                    <li>
                                        <strong>Cấu hình tối thiểu</strong>
                                        <ul>
                                            <li>CPU: Intel P4/NetBurst Architecture or its AMD Equivalent (AMD K7)</li>
                                            <li>CPU Speed: Info</li>
                                            <li>RAM: 2 GB</li>
                                            <li>OS: Windows XP or better</li>
                                            <li>Video Card: Intel GMA 950 or AMD Equivalent</li>
                                            <li>Sound Card: Yes</li>
                                            <li>Free Disk Space: 200 MB</li>
                                        </ul>
                                    </li>
                                    <li>
                                        <strong>Cấu hình đề nghị</strong>
                                        <ul>
                                            <li>CPU: Intel Core i3 or AMD Athlon II (K10) 2.8 GHz</li>
                                            <li>CPU Speed: Info</li>
                                            <li>RAM: 4 GB</li>
                                            <li>OS: Windows XP or better</li>
                                            <li>Video Card: GeForce 2xx Series or AMD Radeon HD 5xxx Series (Excluding Integrated Chipsets) with OpenGL 3.3</li>
                                            <li>Sound Card: Yes</li>
                                            <li>Free Disk Space: 1 GB</li>
                                        </ul>
                                    </li>
                                </ul>
                                <br/>
                                <h2>Tải Minecraft Bedrock Edition:</h2>
                                <h3>1. Giới thiệu</h3>
                                <p>Là một phiên bản Minecraft được lập trình lại nhằm tránh sự phân rã quá nhiều phiên bản trên nhiều thiết bị giống nhau như Legacy Edition, viết bằng ngôn ngữ C++, người chơi có thể mua/tải về các DLC qua Minecraft Marketplace hoặc cài mod như Java Edition (Chỉ hỗ trợ trên điện thoại). Bedrock Edition được viết nhằm hỗ trợ chơi trực tuyến đa nền tảng (cross-platform multiplayer).</p>
                                <h3>2. Tải Minecraft Bedrock Edition</h3>
                                <ul>
                                    <li><b>Nếu bạn đã mua minecraft</b>, Hãy tải từ các cửa hàng ứng dụng</li>
                                    <div style="display: block">
                                        <a href="https://play.google.com/store/apps/details?id=com.mojang.minecraftpe">
                                            <img src="/assets/img/ggplay.webp" class="store-down down-google">
                                        </a>
                                        <a href="https://apps.apple.com/app/minecraft/id479516143">
                                            <img src="/assets/img/appstore.webp" class="store-down down-apple">
                                        </a>
                                    </div>
                                    <div style="">
                                        <li>Nếu bạn chưa mua, nhấn vào nút <b>Download</b> bên dưới để truy cập trang tải xuổng (Android)</li>

                                        <div class="mc-menu">
                                            <div class="double">
                                                <a href="https://drive.google.com/file/d/1V4e-fad7sbV0bny_CYGvFnHzfbOQ-C3-/view?usp=sharing">
                                                    <div class="mc-button">
                                                        <div class="title">Google Drive</div>
                                                    </div>
                                                </a>
                                                <a href="https://www.mediafire.com/file/3yuqtwlkfimzr6v/Minecraft_1.17.40.06_OFFICIAL.apk/file">
                                                    <div class="mc-button">
                                                        <div class="title">Mediafire</div>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="mc-menu">
                                            <div class="double">
                                                <a href="https://mega.nz/file/Kolnwa6B#E-3cGEB2fKM7ZgJDk8KBunrikrxhzsil8Mx8y5IzM-g">
                                                    <div class="mc-button">
                                                        <div class="title">Mega.nz 1</div>
                                                    </div>
                                                </a>
                                                <a href="https://mega.nz/file/bkdnTQaK#fLzXInrqL-CsVRwQtQZLPqVJHg3QNbUkz5Qlocfab4o">
                                                    <div class="mc-button">
                                                        <div class="title">Mega.nz 2</div>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </ul>
                                <h3>3. Cấu hình yêu cầu</h3>
                                <ul>
                                    <li><b>ANDROID</b></li>
                                    <ul>
                                        <li>Hệ điều hành: Android 5.0 trở lên</li>
                                        <li>Ram: 768MB trở lên</li>
                                        <li>Bộ nhớ trống: Tổi thiểu 300MB</li>
                                    </ul>
                                    <li><b>IOS</b></li>
                                    <ul>
                                        <li>Hệ điều hành: Ios 10.0 trở lên</li>
                                        <li>Ram: 512MB trở lên</li>
                                        <li>Bộ nhớ trống: Tổi thiểu 300MB</li>
                                    </ul>
                                </ul>
                            </section>
                            <footer class="article-footer"></footer>
                        </article>
                    </div>

                    <div class="creepy-content-border creepy-3d-border">
                        <span class="border-left"></span><span class="border-middle"><span></span></span><span class="border-right"></span>
                    </div>
