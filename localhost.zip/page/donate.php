
                    <div class="inner-bg">
                        <article id="post-2" class="clearfix post-2 page type-page status-publish hentry" role="article">
                            <img src="/assets/img/minecraft.jpg" class="magicraft-single-thumb" style="width:100%"/>


                            <header class="article-header">
                                <h1 class="page-title" itemprop="headline">Donate cho server</h1>
                            </header>

                            <section class="entry-content clearfix" itemprop="articleBody">


                            </section>
                            <footer class="article-footer"></footer>
                        </article>
                    </div>

                    <div class="creepy-content-border creepy-3d-border">
                        <span class="border-left"></span><span class="border-middle"><span></span></span><span class="border-right"></span>
                    </div>